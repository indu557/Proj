# 📚 Book Finder App  

## 📖 Overview  
Book Finder is a simple React-based application that allows users to search for books by title using the **Open Library API**. It displays book details such as cover image, title, author(s), and year of first publication.  

---

## ✨ Features  
- 🔍 Search books by title  
- 📊 Displays top 10 results  
- 🖼 Shows cover image (or a placeholder if not available)  
- 👤 Displays author(s)  
- 📅 Shows first publication year  
- ⏳ Loading indicator while fetching results  
- ⚠️ Error message for no results or network issues  

---

## 🛠 Tech Stack  
- **Frontend:** React.js (Hooks, useState)  
- **Styling:** Inline CSS with modern UI design  
- **API:** [Open Library Search API](https://openlibrary.org/developers/api)  

---

## 🚀 How It Works  
1. Enter a book title in the search bar.  
2. Click **Search**.  
3. The app fetches book data from Open Library API.  
4. Results are displayed in card format with image, title, author, and year.  
5. If no books are found, an error message appears.  

---

## 📷 Demo Screenshots  

**Search for “Harry Potter”**  
- Shows multiple books with covers, authors, and years.  

**Search for random text (e.g., “asdjh”)**  
- Shows **“No books found.”**  

---

## 📂 Project Structure  
Book Finder/
│── App.js # Main React component
│── index.js # Entry point
│── README.md # Project documentation

---

## 🏁 How to Run Locally  
1. Clone this project or open in CodeSandbox.  
2. Run the app:  
   ```bash
   npm start
3.Open in your browser → http://localhost:3000

---